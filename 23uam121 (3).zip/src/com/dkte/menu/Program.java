package com.dkte.menu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.dkte.entity.Album;
import com.dkte.entity.Artist;
import com.dkte.entity.Track;
import com.dkte.util.Util;

public class Program {
	////1st method/////
	public static void addArtist(Scanner sc)
	{
	Artist artist=new Artist();
	artist.accept(sc);
	String sql = "INSERT INTO artist(artist_id,name) VALUES(?,?)";
	try (Connection connection = Util.getConnection()) {
		try (PreparedStatement insertStatement = connection.prepareStatement(sql)) {
			insertStatement.setInt(1,artist.getArtist_id());
			insertStatement.setString(2,artist.getName());
			insertStatement.executeUpdate();
			System.out.println("Artist added  successsfully...");
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
	///////////////////2nd method////////////////////////////////////////////
	public static void addAlbum(Scanner sc) {
	    Album album = new Album();
	    album.accept(sc);
	    String sql = "INSERT INTO album(album_id, title) VALUES(?,?)";
	    try (Connection connection = Util.getConnection()) {
	        try (PreparedStatement insertStatement = connection.prepareStatement(sql)) {
	            insertStatement.setInt(1, album.getAlbum_id());
	            insertStatement.setString(2, album.getTitle());
	            insertStatement.executeUpdate();
	            System.out.println("Album added successfully...");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
/////3rd method//////////////////////////////////////////////////////////////
	private static void addTrackForAlbum(Scanner sc) {
	    Track track = new Track();
	    boolean validInput = false;
	    while (!validInput) {
	        try {
	            System.out.print("Enter the artist id - ");
	            track.setArtist_id(sc.nextInt());
	            sc.nextLine();
	            System.out.print("Enter the album id - ");
	            track.setAlbum_id(sc.nextInt());
	            sc.nextLine();
	            System.out.print("Enter the track id - ");
	            track.setTrack_id(sc.nextInt());
	            sc.nextLine();
	            System.out.print("Enter the track title - ");
	            track.setTitle(sc.nextLine());
	            if (track.getArtist_id() <= 0 || track.getAlbum_id() <= 0 || track.getTrack_id() <= 0 || track.getTitle().isEmpty()) {
	                System.out.println("Invalid input. Please enter valid details.");
	            } else {
	                validInput = true;
	            }
	        } catch (InputMismatchException e) {
	            System.out.println("Invalid input. Please enter a valid number.");
	            sc.nextLine(); 
	        }
	    }
	    String sql = "INSERT INTO track (track_id, title, album_id, artist_id) VALUES (?, ?, ?, ?)";
	    try (Connection connection = Util.getConnection()) {
	        try (PreparedStatement insertStatement = connection.prepareStatement(sql)) {
	            insertStatement.setInt(1, track.getTrack_id());
	            insertStatement.setString(2, track.getTitle());
	            insertStatement.setInt(3, track.getAlbum_id());
	            insertStatement.setInt(4, track.getArtist_id());
	            insertStatement.executeUpdate();
	            System.out.println("Track added successfully...");
	        }
	    } catch (SQLException e) {
	        System.out.println("Error adding track: " + e.getMessage());
	    }
	}
	////////////4th method/////////////////////////////////////////////
	private static void displayArtists() {
	    String sql = "SELECT * FROM artist";
	    try (Connection connection = Util.getConnection()) {
	        try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
	            ResultSet rs = selectStatement.executeQuery();
	            List<Artist> artistList = new ArrayList<>();
	            while (rs.next()) {
	                Artist artist = new Artist();
	                artist.setArtist_id(rs.getInt(1));
	                artist.setName(rs.getString(2));
	                artistList.add(artist);
	            }
	            artistList.forEach(m -> System.out.println(m));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	/////////////////5th method///////////////////////////////////////////
	private static void displayAlbums() {
	    String sql = "SELECT * FROM album";
	    try (Connection connection = Util.getConnection()) {
	        try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
	            ResultSet rs = selectStatement.executeQuery();
	            List<Album> albumList = new ArrayList<>();
	            while (rs.next()) {
	                Album album = new Album();
	                album.setAlbum_id(rs.getInt(1));
	                album.setTitle(rs.getString(2));
	                albumList.add(album);
	            }
	            albumList.forEach(a -> System.out.println(a));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	//////////////////////////6th method/////////////////
	private static void viewTracksForArtist(Scanner sc) {
	    System.out.print("Enter the artist id - ");
	    int artistId = sc.nextInt();
	    sc.nextLine();
	    String sql = "SELECT * FROM track WHERE artist_id = ?";
	    try (Connection connection = Util.getConnection()) {
	        try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
	            selectStatement.setInt(1, artistId);
	            ResultSet rs = selectStatement.executeQuery();
	            List<Track> trackList = new ArrayList<>();
	            while (rs.next()) {
	                Track track = new Track();
	                track.setTrack_id(rs.getInt(1));
	                track.setTitle(rs.getString(2));
	                track.setAlbum_id(rs.getInt(3));
	                track.setArtist_id(rs.getInt(4));
	                trackList.add(track);
	            }
	            if (trackList.isEmpty()) {
	                System.out.println("No tracks found for the artist.");
	            } else {
	                trackList.forEach(t -> System.out.println(t));
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
/////////////////////////////7th method////////////////////////////
	private static void displayAllTracks() {
	    String sql = "SELECT * FROM track";
	    try (Connection connection = Util.getConnection()) {
	        try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
	            ResultSet rs = selectStatement.executeQuery();
	            List<Track> trackList = new ArrayList<>();
	            while (rs.next()) {
	                Track track = new Track();
	                track.setTrack_id(rs.getInt(1));
	                track.setTitle(rs.getString(2));
	                track.setAlbum_id(rs.getInt(3));
	                track.setArtist_id(rs.getInt(4));
	                trackList.add(track);
	            }
	            if (trackList.isEmpty()) {
	                System.out.println("No tracks found.");
	            } else {
	                trackList.forEach(t -> System.out.println(t));
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	//////////////////8th method///////////////////////
	private static void viewTracksForAlbum(Scanner sc) {
	    System.out.print("Enter the album id - ");
	    int albumId = sc.nextInt();
	    sc.nextLine();
	    String sql = "SELECT * FROM track WHERE album_id = ?";
	    try (Connection connection = Util.getConnection()) {
	        try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
	            selectStatement.setInt(1, albumId);
	            ResultSet rs = selectStatement.executeQuery();
	            List<Track> trackList = new ArrayList<>();
	            while (rs.next()) {
	                Track track = new Track();
	                track.setTrack_id(rs.getInt(1));
	                track.setTitle(rs.getString(2));
	                track.setAlbum_id(rs.getInt(3));
	                track.setArtist_id(rs.getInt(4));
	                trackList.add(track);
	            }
	            if (trackList.isEmpty()) {
	                System.out.println("No tracks found for the album.");
	            } else {
	                trackList.forEach(t -> System.out.println(t));
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

public static int menu(Scanner sc) {
		System.out.println("****************************");
		System.out.println("0. EXIT");
		System.out.println("1.Add a new artist");
		System.out.println("2.Add a new album");
		System.out.println("3.Adds a track for the album");
		System.out.println("4.Display all artists");
		System.out.println("5.Display all albums");
		System.out.println("6.View all tracks for a given artist");
		System.out.println("7.Display all tracks");
		System.out.println("8.View all tracks for a given album");
System.out.print("Enter the choice - ");
		int choice = sc.nextInt();
		System.out.println("****************************");
		return choice;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Artist artist = null;
		int choice;
		while ((choice = menu(sc)) != 0) {
			switch (choice) {
			case 1:
				addArtist(sc);
				break;
			case 2:
				addAlbum(sc);
				break;
			case 3:
				addTrackForAlbum(sc);
				break;
			case 4:
				displayArtists();
				break;
			case 5:
				displayAlbums();
				break;
			case 6:
				viewTracksForArtist(sc);
				break;
			case 7:
				displayAllTracks();
				break;
				
			case 8:
				viewTracksForAlbum(sc);
				break;
				
				default:
				System.out.println("Wrong choice ... :(");
				break;
			}
		}
		sc.close();
		System.out.println("Thank you for using our app :)");
	}




	}


