package com.dkte.entity;

import java.util.Scanner;

public class Artist {
	private int artist_id;
	private String name;
	//constructors
	public Artist()
	{
		
	}
	public Artist(int artist_id, String name) {
		super();
		this.artist_id = artist_id;
		this.name = name;
	}
	//getter setter
	public int getArtist_id() {
		return artist_id;
	}
	public void setArtist_id(int artist_id) {
		this.artist_id = artist_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void accept(Scanner sc) {
        System.out.print("Enter the artist's id - ");
        artist_id = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter the artist's name - ");
        name = sc.nextLine();
    }
	@Override
	public String toString() {
		return "Artist [artist_id=" + artist_id + ", name=" + name + "]";
	}
	
	

}
