/**
 * 
 */
/**
 * 
 */
module OOP2_23UAM121 {
	requires java.sql;
}